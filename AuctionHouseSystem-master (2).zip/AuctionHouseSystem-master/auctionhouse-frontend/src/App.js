import React from 'react';
import './App.css';
import Routing from './components/routing.component'

function App() {
  return (
    <div className="App">
      <Routing></Routing>
    </div>
  );
}

export default App;
