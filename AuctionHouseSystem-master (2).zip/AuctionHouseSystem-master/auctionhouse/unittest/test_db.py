from auctionhouse.data.db import read_auctions_from_query

# if __name__=="__main__":
#     read_auctions_from_query({})